fx_version 'cerulean'
game 'gta5'

author 'Solyx'
description 'Server Status Discord Updater'
version '1.0.0'

server_script 'server.lua'

local webhook "" -- discord webhook, click on the text category, aka server-status, edit, integrations, then webhook!
local serverName = "" -- change this to your server name

-- function to send message to Discord
function sendToDiscord(status)
    local embeds = {{
        ["title"] = serverName .. " Status",
        ["description"] = "The server is now **" .. status .. "**",
        ["color"] = (status == "OPEN" and 3066993) or 15158332 -- green for open, red for closed
    }}
    
    PerformHttpRequest(webhook, function(err, text, headers) end, 'POST', json.encode({username = "Server Status", embeds = embeds}), { ['Content-Type'] = 'application/json' })
end

-- when server starts
AddEventHandler('onResourceStart', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        sendToDiscord("OPEN ✅")
    end
end)

-- when server stops
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        sendToDiscord("CLOSED ❌")
    end
end)
